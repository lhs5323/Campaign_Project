class Director < ActiveRecord::Base
    attr_accessible :name, :email
end