require 'rails_helper'

RSpec.describe DirectorsController, :type => :controller do
    describe 'showing a task' do
    end
end