# Replace API_KEY and API_SECRET with the values you got from Twitter
Rails.application.config.middleware.use OmniAuth::Builder do
    provider :twitter, "fmtVSx7UEApNwoDLQcP2kz5ho", "eKam72mmgoilhK4ikKstC4T8BVfPSj0NWL4s2szM6hcNi7tq9X"
end